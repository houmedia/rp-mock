[README.md](https://github.com/user-attachments/files/27366745/README.md)
# The Rod Paige Scholars & Leaders Foundation
### Official Website Repository

This repository contains the official website for **The Rod Paige Scholars & Leaders Foundation**, established in honor of Dr. Roderick Raynor Paige Sr. (June 17, 1933 – December 9, 2025) — the 7th United States Secretary of Education and the first African American to hold that office.

---

## About the Foundation

The Rod Paige Scholars & Leaders Foundation exists to carry forward Dr. Paige's lifelong conviction that education is the great equalizer — that where a child is born should never determine whether that child can succeed. The Foundation awards scholarships to students of exceptional promise who are entering the field of education, and supports mentorship, leadership development, and the preservation of Dr. Paige's historical legacy.

**Contact:** info@rodpaigescholars.org
**Donations:** donations@rodpaigescholars.org
**Mailing Address:** P.O. Box 27350 · Houston, Texas 77227

---

## About This Website

The website is a single-file static HTML application — self-contained, fast, and secure.

### Technical Overview

| Property | Detail |
|---|---|
| **Architecture** | Single-file static HTML |
| **Pages** | Home · Life Story · Archives · Articles · Scholarships · Donate |
| **Images** | Base64-embedded (no external image server required) |
| **Fonts** | Google Fonts — Cormorant Garamond, Didact Gothic, Libre Baskerville |
| **Dependencies** | Google Fonts only (one external CDN link) |
| **Framework** | None — pure HTML, CSS, and vanilla JavaScript |
| **File** | `index.html` |

### Design System

- **Navy** `#0D1B2A` — primary background, authority
- **Gold** `#C9A84C` — legacy, dignity, honor
- **Crimson** `#C0202F` — presidential accent, action

### Pages

- **Home** — Hero, featured photographs, biography excerpt, milestone timeline, tributes, mission statement
- **Life Story** — Full eight-chapter biography from 1933 to 2025
- **Archives** — Photo archive organized by era: The Coach · Houston Years · Washington D.C. · Legacy
- **Articles** — Writings by Dr. Paige and major legacy coverage
- **Scholarships** — Scholarship description, eligibility criteria, and application form
- **Donate** — Three giving methods: credit card, Zelle, and check by mail

---

## Hosting

This site is designed to be hosted on any static file hosting service. Recommended platforms:

- **[Netlify](https://www.netlify.com)** — drag and drop deployment, free HTTPS, free tier available
- **[Vercel](https://vercel.com)** — fast global CDN, free tier available
- **[GitHub Pages](https://pages.github.com)** — free, directly from this repository

### To deploy on GitHub Pages
1. Go to **Settings → Pages**
2. Set Branch to `main`
3. Click **Save**
4. The site will be live at `https://cbandy1111.github.io/RPSL`

---

## For Developers

### Getting started

No build tools, package managers, or local servers are required. Open `index.html` directly in any modern browser to view the site.

```bash
# Clone the repository
git clone https://github.com/cbandy1111/RPSL.git

# Open in browser (macOS)
open index.html

# Open in browser (Windows)
start index.html
```

### To make edits

The entire site lives in `index.html`. It is organized in clearly commented sections:

```
<!-- ═══════════ HOME ═══════════ -->
<!-- ═══════════ LIFE STORY ═══════════ -->
<!-- ═══════════ ARCHIVE ═══════════ -->
<!-- ═══════════ ARTICLES ═══════════ -->
<!-- ═══════════ SCHOLARSHIPS ═══════════ -->
<!-- ═══════════ DONATE ═══════════ -->
```

### Planned integrations (not yet implemented)

- **Payment processing** — Stripe integration for the donation form (nonprofit discount available at stripe.com)
- **Form backend** — Formspree or Netlify Forms for the scholarship application
- **Email** — Google Workspace for Nonprofits for info@ and donations@ addresses
- **Domain** — Custom domain to replace the GitHub Pages URL
- **DNS security** — SPF, DKIM, and DMARC records once email is configured

---

## Photo Credits

Photographs in the archive are either provided by the Paige family, sourced from Associated Press archives, or are public domain images from Wikimedia Commons. All photos are embedded directly in the HTML file as base64-encoded data.

---

## License

© 2026 The Rod Paige Scholars & Leaders Foundation. All rights reserved.

This repository is maintained for the purpose of operating the Foundation's public website. The content, photographs, and design are the property of The Rod Paige Scholars & Leaders Foundation and may not be reproduced without written permission.

---

*"Education is the key that unlocks the door to opportunity — not just for individuals, but for our nation."*
**— Dr. Rod Paige, 7th U.S. Secretary of Education**
